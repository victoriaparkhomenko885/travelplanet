function AvtoLogPas(login, password){

if(/^[a-zA-Z1-9]+$/.test(login) === false)
	{alert('У логіні повинні бути тільки латинські букви'); return false;}
if(login.length < 4 || login.length > 20)
	{ alert('Логін повинен бути від 4 до 20 символів'); return false;}
if(parseInt(login.substr(0, 1)))
	{alert('Логін повинен починатися з літери'); return false;}

if(/^[a-zA-Z1-9]+$/.test(password) === false)
	{alert('Пароль повинен бути тільки латинськими буквами'); return false;}
if(password.length < 8 || password.length > 20)
	{ alert('Пароль повинен бути від 4 до 20 символів'); return false;}

 return AvtoSuccess(login);
}

function AvtoSuccess(login){
  setTimeout('window.location="index.html"', 1000);
  return alert('Ви успішно авторизувалися!');
} 


